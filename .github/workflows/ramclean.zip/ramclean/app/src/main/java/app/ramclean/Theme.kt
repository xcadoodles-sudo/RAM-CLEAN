package app.ramclean

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Light = lightColorScheme(
    primary = Color(0xFF161616), onPrimary = Color.White,
    background = Color(0xFFFAFAFA), onBackground = Color(0xFF161616),
    surface = Color(0xFFFAFAFA), onSurface = Color(0xFF161616),
    surfaceVariant = Color(0xFFEDEDED), onSurfaceVariant = Color(0xFF707070),
    outline = Color(0xFFDADADA),
)
private val Dark = darkColorScheme(
    primary = Color(0xFFF2F2F2), onPrimary = Color(0xFF111111),
    background = Color(0xFF0D0D0D), onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF0D0D0D), onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF242424), onSurfaceVariant = Color(0xFF9A9A9A),
    outline = Color(0xFF333333),
)

@Composable
fun RamCleanTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
