package app.ramclean

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

enum class AccessState { NOT_RUNNING, NO_PERMISSION, READY }

/** Status & izin layanan Shizuku (AX Manager menyediakan API yang kompatibel). */
object Access {
    private const val REQUEST_CODE = 1001

    fun state(): AccessState = try {
        when {
            !Shizuku.pingBinder() -> AccessState.NOT_RUNNING
            Shizuku.isPreV11() -> AccessState.NOT_RUNNING
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> AccessState.READY
            else -> AccessState.NO_PERMISSION
        }
    } catch (_: Throwable) {
        AccessState.NOT_RUNNING
    }

    fun request() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) {
        }
    }
}

/** Menjalankan perintah shell dengan hak akses shell (via Shizuku / AX Manager). */
object Shell {
    // Shizuku.newProcess bersifat private sejak 13.x; dipanggil lewat reflection.
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java,
        ).apply { isAccessible = true }
    }

    fun run(command: String): String {
        val process = newProcess.invoke(null, arrayOf("sh", "-c", "$command 2>&1"), null, null) as Process
        val out = process.inputStream.bufferedReader().use { it.readText() }
        process.waitFor()
        return out
    }
}
