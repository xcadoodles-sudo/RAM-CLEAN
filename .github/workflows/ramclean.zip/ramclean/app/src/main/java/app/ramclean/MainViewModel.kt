package app.ramclean

import android.app.ActivityManager
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class Filter { ALL, USER, SYSTEM }

data class UiState(
    val access: AccessState = AccessState.NOT_RUNNING,
    val totalBytes: Long = 0,
    val availBytes: Long = 0,
    val apps: List<RunningApp> = emptyList(),
    val selected: Set<String> = emptySet(),
    val whitelist: Set<String> = emptySet(),
    val filter: Filter = Filter.ALL,
    val busy: Boolean = false,
    val message: String? = null,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val prefs = Prefs(ctx)
    private val _ui = MutableStateFlow(UiState(whitelist = prefs.whitelist()))
    val ui = _ui.asStateFlow()

    private val onBinder = Shizuku.OnBinderReceivedListener { refresh() }
    private val onDead = Shizuku.OnBinderDeadListener { refresh() }
    private val onPermission = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    init {
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPermission)
        refresh()
    }

    override fun onCleared() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPermission)
    }

    private fun readMem(): Pair<Long, Long> {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        return mi.totalMem to mi.availMem
    }

    private suspend fun load() {
        val st = Access.state()
        val (total, avail) = readMem()
        var failed = false
        val apps = if (st == AccessState.READY) {
            withContext(Dispatchers.IO) {
                runCatching { AppScanner.scan(ctx) }.onFailure { failed = true }.getOrDefault(emptyList())
            }
        } else emptyList()
        _ui.update { s ->
            s.copy(
                access = st,
                totalBytes = total,
                availBytes = avail,
                apps = apps,
                selected = s.selected.intersect(apps.map { it.pkg }.toSet()),
                message = if (failed) "Gagal membaca daftar proses" else s.message,
            )
        }
    }

    fun refresh() {
        viewModelScope.launch { load() }
    }

    fun requestAccess() = Access.request()

    fun setFilter(f: Filter) = _ui.update { it.copy(filter = f) }

    fun toggle(pkg: String) = _ui.update {
        it.copy(selected = if (pkg in it.selected) it.selected - pkg else it.selected + pkg)
    }

    fun toggleWhitelist(pkg: String) {
        _ui.update {
            val wl = if (pkg in it.whitelist) it.whitelist - pkg else it.whitelist + pkg
            prefs.saveWhitelist(wl)
            it.copy(whitelist = wl, selected = it.selected - pkg)
        }
    }

    fun selectRecommended() = _ui.update { s ->
        s.copy(selected = s.apps.filter { it.recommended && it.pkg !in s.whitelist }.map { it.pkg }.toSet())
    }

    fun consumeMessage() = _ui.update { it.copy(message = null) }

    fun clean() {
        val s = _ui.value
        val targets = (s.selected - s.whitelist).filter { it.matches(Regex("[A-Za-z0-9._]+")) }
        if (targets.isEmpty() || s.busy) return
        viewModelScope.launch {
            _ui.update { it.copy(busy = true) }
            val before = readMem().second
            withContext(Dispatchers.IO) {
                runCatching { Shell.run(targets.joinToString("; ") { "am force-stop $it" }) }
            }
            delay(1200)
            _ui.update { it.copy(selected = emptySet()) }
            load()
            val freed = _ui.value.availBytes - before
            val msg = "${targets.size} app dihentikan" + if (freed > 0) " · +${fmtBytes(freed)} lega" else ""
            _ui.update { it.copy(busy = false, message = msg) }
        }
    }
}
