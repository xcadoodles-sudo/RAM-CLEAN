package app.ramclean

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.provider.Settings

data class RunningApp(
    val pkg: String,
    val label: String,
    val rssKb: Long,
    val isSystem: Boolean,
    val recommended: Boolean,
)

/** App sistem yang umumnya tidak penting-penting amat dan aman dihentikan sementara. */
object Recommendations {
    private val exact = setOf(
        // Xiaomi / HyperOS
        "com.miui.analytics", "com.miui.msa.global", "com.miui.systemAdSolution",
        "com.xiaomi.mipicks", "com.xiaomi.discover", "com.miui.hybrid", "com.miui.hybrid.accessory",
        "com.miui.bugreport", "com.miui.daemon", "com.miui.cloudservice", "com.miui.cloudbackup",
        "com.miui.yellowpage", "com.miui.player", "com.miui.videoplayer", "com.miui.fm",
        "com.miui.compass", "com.miui.weather2", "com.miui.screenrecorder", "com.miui.mediaeditor",
        "com.miui.gallery", "com.miui.contentcatcher", "com.miui.catcherpatch", "com.miui.smsextra",
        "com.miui.touchassistant", "com.miui.voiceassist", "com.miui.miservice",
        "com.miui.android.fashiongallery", "com.miui.carlink", "com.xiaomi.aiasst.vision",
        "com.xiaomi.aiasst.service", "com.xiaomi.scanner", "com.xiaomi.glgm",
        "com.xiaomi.gamecenter.sdk.service", "com.xiaomi.payment", "com.mipay.wallet",
        "com.mi.globalbrowser", "com.android.browser",
        // Google
        "com.google.android.youtube", "com.google.android.apps.youtube.music",
        "com.google.android.apps.photos", "com.google.android.apps.maps", "com.google.android.apps.docs",
        "com.google.android.videos", "com.google.android.music", "com.google.android.apps.tachyon",
        "com.google.android.apps.googleassistant", "com.google.android.googlequicksearchbox",
        "com.google.android.apps.messaging", "com.google.android.apps.magazines",
        "com.google.android.apps.subscriptions.red", "com.google.android.apps.nbu.files",
        "com.google.android.projection.gearhead", "com.google.android.feedback",
        "com.google.android.apps.chromecast.app",
    )
    private val prefixes = listOf("com.google.android.apps.docs.editors.")

    fun isRecommended(pkg: String) = pkg in exact || prefixes.any { pkg.startsWith(it) }
}

/** App inti sistem yang tidak boleh disentuh sama sekali (tidak ditampilkan di daftar). */
object Protection {
    private val exact = setOf(
        "android", "com.android.systemui", "com.miui.home", "com.miui.securitycenter",
        "com.miui.core", "com.miui.powerkeeper", "com.xiaomi.xmsf", "com.google.android.gms",
        "com.google.android.gsf", "com.google.android.webview", "com.google.android.permissioncontroller",
        "com.google.android.packageinstaller",
    )
    private val prefixes = listOf(
        "com.android.providers.", "com.android.inputmethod.", "com.android.server.",
        "com.android.phone", "com.android.bluetooth", "com.android.nfc", "com.android.settings",
        "com.android.shell", "com.android.permissioncontroller", "com.android.networkstack",
        "com.android.wifi", "com.android.cellbroadcast", "com.android.keychain",
        "com.android.location", "com.android.externalstorage", "com.android.packageinstaller",
        "com.android.mtp", "com.android.se", "com.android.incallui", "com.android.stk",
        "com.android.managedprovisioning", "com.qualcomm", "com.qti", "org.codeaurora",
        "vendor.", "com.google.android.ext.", "com.miui.system", "com.miui.securitycore",
        "com.miui.guardprovider",
    )

    /** Launcher aktif, keyboard aktif, aplikasi ini sendiri, dan AX Manager/Shizuku. */
    fun dynamic(ctx: Context): Set<String> {
        val pm = ctx.packageManager
        val out = mutableSetOf(ctx.packageName)
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        pm.queryIntentActivities(home, 0).forEach { out += it.activityInfo.packageName }
        Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')?.let { out += it }
        pm.getInstalledApplications(0).forEach {
            val p = it.packageName.lowercase()
            if ("shizuku" in p || "axeron" in p || "axmanager" in p) out += it.packageName
        }
        return out
    }

    fun isProtected(pkg: String, dynamic: Set<String>) =
        pkg in dynamic || pkg in exact || prefixes.any { pkg.startsWith(it) }
}

object AppScanner {
    /** Baca proses yang sedang berjalan lewat `ps`, gabungkan per paket, jumlahkan RSS. */
    fun scan(ctx: Context): List<RunningApp> {
        val pm = ctx.packageManager
        val output = Shell.run("ps -A -o RSS,NAME")
        val rss = HashMap<String, Long>()
        output.lineSequence().forEach { line ->
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size < 2) return@forEach
            val kb = parts[0].toLongOrNull() ?: return@forEach
            rss.merge(parts[1].substringBefore(':'), kb, Long::plus)
        }
        val installed = pm.getInstalledApplications(0).associateBy { it.packageName }
        val dynamic = Protection.dynamic(ctx)
        return rss.mapNotNull { (pkg, kb) ->
            val info = installed[pkg] ?: return@mapNotNull null
            if (Protection.isProtected(pkg, dynamic)) return@mapNotNull null
            val system = info.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            RunningApp(
                pkg = pkg,
                label = info.loadLabel(pm).toString(),
                rssKb = kb,
                isSystem = system,
                recommended = system && Recommendations.isRecommended(pkg),
            )
        }.sortedByDescending { it.rssKb }
    }
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("ramclean", Context.MODE_PRIVATE)
    fun whitelist(): Set<String> = sp.getStringSet("whitelist", emptySet()) ?: emptySet()
    fun saveWhitelist(s: Set<String>) = sp.edit().putStringSet("whitelist", s.toSet()).apply()
}

fun fmtBytes(b: Long): String {
    val gb = b / 1073741824.0
    return if (gb >= 1) "%.1f GB".format(gb) else "${b / 1048576} MB"
}

fun fmtKb(kb: Long) = fmtBytes(kb * 1024)
