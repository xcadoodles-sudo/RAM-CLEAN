package app.ramclean

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainScreen(vm: MainViewModel) {
    val s by vm.ui.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    var confirm by remember { mutableStateOf(false) }

    LaunchedEffect(s.message) {
        s.message?.let {
            snack.showSnackbar(it)
            vm.consumeMessage()
        }
    }

    val visible = when (s.filter) {
        Filter.ALL -> s.apps
        Filter.USER -> s.apps.filter { !it.isSystem }
        Filter.SYSTEM -> s.apps.filter { it.isSystem }
    }
    val targets = s.apps.filter { it.pkg in s.selected && it.pkg !in s.whitelist }
    val needsConfirm = targets.any { it.isSystem && !it.recommended }
    val used = if (s.totalBytes > 0) (s.totalBytes - s.availBytes).toFloat() / s.totalBytes else 0f

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.TopCenter) {
            Column(Modifier.widthIn(max = 640.dp).fillMaxSize().padding(horizontal = 24.dp)) {
                Spacer(Modifier.height(24.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    RamRing(
                        fraction = used,
                        label = "${(used * 100).toInt()}%",
                        sub = "${fmtBytes(s.totalBytes - s.availBytes)} dari ${fmtBytes(s.totalBytes)}",
                        onClick = vm::refresh,
                    )
                }
                Spacer(Modifier.height(20.dp))

                when (s.access) {
                    AccessState.NOT_RUNNING -> Notice(
                        title = "AX Manager belum aktif",
                        body = "Nyalakan layanan AX Manager (mode Shizuku), lalu cek lagi.",
                        action = "Cek lagi",
                        onAction = vm::refresh,
                    )
                    AccessState.NO_PERMISSION -> Notice(
                        title = "Izin diperlukan",
                        body = "Beri akses ke RAM Clean lewat AX Manager.",
                        action = "Beri izin",
                        onAction = vm::requestAccess,
                    )
                    AccessState.READY -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Segment("Semua", s.filter == Filter.ALL) { vm.setFilter(Filter.ALL) }
                            Segment("Pengguna", s.filter == Filter.USER) { vm.setFilter(Filter.USER) }
                            Segment("Sistem", s.filter == Filter.SYSTEM) { vm.setFilter(Filter.SYSTEM) }
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = vm::selectRecommended) { Text("Pilih Recommended") }
                        }
                        if (visible.isEmpty()) {
                            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Text(
                                    "Tidak ada app yang bisa dibersihkan.",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        } else {
                            LazyColumn(Modifier.weight(1f)) {
                                items(visible, key = { it.pkg }) { app ->
                                    AppRow(
                                        app = app,
                                        checked = app.pkg in s.selected,
                                        locked = app.pkg in s.whitelist,
                                        onClick = { vm.toggle(app.pkg) },
                                        onLongClick = { vm.toggleWhitelist(app.pkg) },
                                    )
                                }
                                item {
                                    Text(
                                        "Tekan lama untuk mengecualikan app · ketuk lingkaran untuk menyegarkan",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(vertical = 16.dp),
                                    )
                                }
                            }
                        }
                    }
                }

                if (s.access != AccessState.READY) Spacer(Modifier.weight(1f))

                Button(
                    onClick = { if (needsConfirm) confirm = true else vm.clean() },
                    enabled = targets.isNotEmpty() && !s.busy && s.access == AccessState.READY,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) {
                    Text(
                        when {
                            s.busy -> "Membersihkan…"
                            targets.isEmpty() -> "Pilih app untuk dibersihkan"
                            else -> "Bersihkan ${targets.size} app · ≈ ${fmtKb(targets.sumOf { it.rssKb })}"
                        },
                    )
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Ada app sistem") },
            text = {
                Text(
                    "Sebagian app sistem yang dipilih tidak bertanda Recommended. " +
                        "Menghentikannya bisa membuat notifikasi atau fitur berhenti sementara. Lanjutkan?",
                )
            },
            confirmButton = { TextButton(onClick = { confirm = false; vm.clean() }) { Text("Lanjutkan") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Batal") } },
        )
    }
}

@Composable
private fun RamRing(fraction: Float, label: String, sub: String, onClick: () -> Unit) {
    val animated by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(700), label = "ring")
    val track = MaterialTheme.colorScheme.surfaceVariant
    val arc = MaterialTheme.colorScheme.primary
    Box(
        Modifier.size(200.dp).clip(RoundedCornerShape(100.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 10.dp.toPx()
            val topLeft = Offset(stroke / 2, stroke / 2)
            val arcSize = Size(size.width - stroke, size.height - stroke)
            drawArc(track, 0f, 360f, false, topLeft, arcSize, style = Stroke(stroke))
            drawArc(arc, -90f, 360f * animated, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontSize = 48.sp, fontWeight = FontWeight.Light)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Segment(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp),
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        color = if (selected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun Notice(title: String, body: String, action: String, onAction: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(20.dp),
    ) {
        Text(title, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onAction, shape = RoundedCornerShape(12.dp)) { Text(action) }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppRow(app: RunningApp, checked: Boolean, locked: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = { if (!locked) onClick() }, onLongClick = onLongClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(app.pkg)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (app.recommended) {
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Recommended",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.primary)
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                }
            }
            Text(
                "${if (app.isSystem) "Sistem" else "Pengguna"} · ${fmtKb(app.rssKb)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (locked) {
            Icon(Icons.Filled.Lock, contentDescription = "Dikecualikan", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
        } else {
            Checkbox(checked = checked, onCheckedChange = null)
        }
    }
}

@Composable
private fun AppIcon(pkg: String) {
    val pm = LocalContext.current.packageManager
    val bmp = remember(pkg) {
        runCatching { pm.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
    }
    if (bmp != null) {
        Image(bmp, contentDescription = null, modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)))
    } else {
        Spacer(Modifier.size(40.dp))
    }
}
