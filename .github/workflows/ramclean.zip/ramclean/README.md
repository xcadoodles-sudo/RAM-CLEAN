# RAM Clean

Pembersih RAM minimalis untuk Android (dibuat untuk Xiaomi Pad 6S Pro). Memakai AX Manager (API kompatibel Shizuku) untuk menjalankan `am force-stop` pada app yang kamu pilih — tanpa root.

## Fitur
- Indikator RAM terpakai/tersedia
- Daftar app yang sedang berjalan (pengguna + sistem), diurutkan dari yang paling berat
- Label **Recommended** untuk app sistem yang tidak penting-penting amat
- Pilih manual, atau satu ketuk "Pilih Recommended"
- Tekan lama untuk mengecualikan app (whitelist)
- Launcher, keyboard aktif, AX Manager/Shizuku, dan layanan inti sistem tidak pernah ditampilkan

## Build
- Android Studio: buka folder ini, tunggu sync, Run.
- GitHub Actions: push ke `main`, ambil APK di tab Actions → artifact `ram-clean-debug`.

## Pakai
1. Nyalakan layanan AX Manager (mode Shizuku).
2. Buka RAM Clean → Beri izin.
3. Pilih app → Bersihkan.

Edit daftar Recommended / Protected di `Apps.kt`.
